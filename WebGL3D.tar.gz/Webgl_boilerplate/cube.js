var cubeRotation = 0.0;
var track = [];
var rect_track = [];
var brick_wall = [];
var trains = [];
var vc = [];
var coins = [];
var ground;
var board1 = [];
var board2 = [];
var signal;
var gray = 0;
var score = 0;
var health = 100;
cam_pos = 0;
var light = 0;
main();

var rect;
var rect2;
var cuboid;
var textureCuboid;
var player;
var police;
var boot;
var fly;
var spd;
let count = 0;
let p3 = 0;
let p1 = 0;
let flag1 = 0;
let f1 = 0;
let f2 = 0;
let f3 = 0;
let B1 = 0;
let x_min,x_max,y_min,y_max,z_min,z_max;
let x_1,x_2,y_1,y_2,z_1,z_2;
let a,b,c;
//
// Start here
//


function main() {


    // If we don't have a GL context, give up now

    if (!gl) {
        alert('Unable to initialize WebGL. Your browser or machine may not support it.');
        return;
    }

    // window.addEventListener('keydown', function(event) { Key.onKeydown(event); }, false);

    // Vertex shader program

    const vsSource = `
    attribute vec4 aVertexPosition;
    attribute vec4 aVertexColor;

    uniform mat4 uMVPMatrix;

    varying lowp vec4 vColor;

    void main(void) {
      gl_Position = uMVPMatrix * aVertexPosition;
      vColor = aVertexColor;
    }
  `;

    const vsSrc2 = `
        attribute vec4 aVertexPosition;
        attribute vec2 aTextureCoord;
        
        uniform mat4 uMVPMatrix;
        
        varying highp vec2 vTextureCoord;
        
        void main(void) {
            gl_Position = uMVPMatrix * aVertexPosition;
            vTextureCoord = aTextureCoord;
        }
    `;

    const vsSrcBoth = `
        attribute vec4 aVertexPosition;
        attribute vec2 aTextureCoord;
        attribute vec4 aVertexColor;
        
        uniform mat4 uMVPMatrix;
        
        varying lowp vec4 vColor;
        varying highp vec2 vTextureCoord;
        
        void main(void) {
            gl_Position = uMVPMatrix * aVertexPosition;
            vTextureCoord = aTextureCoord;
            vColor = aVertexColor;
            }
    `;

    // Fragment shader program

    const fsSource = `
    varying lowp vec4 vColor;

    void main(void) {
      gl_FragColor = vColor;
    }
  `;
  	
    const fsSrc2 = `
        varying highp vec2 vTextureCoord;
        
        uniform sampler2D uSampler;
        void main(void) {
            gl_FragColor = texture2D(uSampler, vTextureCoord);
        }
    `;

    const fsSrcboth = `
        varying highp vec2 vTextureCoord;
        varying lowp vec4 vColor;
        uniform sampler2D uSampler;
        uniform bool uGray;
         void main(void) {
            if(uGray)
            {
              highp vec4 texelColor = texture2D(uSampler, vTextureCoord).rgba;
              highp float grayScale = dot(texelColor.rgb, vec3(0.199, 0.587, 0.114));
              highp vec3 grayImage = vec3(grayScale, grayScale, grayScale);
              gl_FragColor = vec4(grayImage , texelColor.a);
            }
            else
            {
              highp vec4 texelColor = texture2D(uSampler, vTextureCoord).rgba;
              highp vec3 Image = vec3(texelColor.r , texelColor.g , texelColor.b );
              gl_FragColor = vec4(Image , texelColor.a);
            }
         }
    `;

    const fsSrcflash = `
        varying highp vec2 vTextureCoord;
        varying lowp vec4 vColor;
        uniform sampler2D uSampler;
         void main(void) {
            highp vec4 texelColor = texture2D(uSampler, vTextureCoord).rgba;
            highp float flashScale = dot(texelColor.rgb, vec3(1.000, 1.000, 1.000));
            highp vec3 flashImage = vec3(flashScale, flashScale, flashScale);
            gl_FragColor = vec4(flashImage , texelColor.a);
         }
    `;
    //highp float grayScale = dot(texelColor.rgb, vec3(0.199, 0.587, 0.114));
    
    // Initialize a shader program; this is where all the lighting
    // for the vertices and so forth is established.
    const shaderProgram2 = initShaderProgram(gl, vsSrcBoth, fsSrcflash);
    const shaderProgram = initShaderProgram(gl, vsSrcBoth, fsSrcboth);
    const shaderProgramColors = initShaderProgram(gl, vsSource, fsSource);

    // Collect all the info needed to use the shader program.
    // Look up which attributes our shader program is using
    // for aVertexPosition, aVevrtexColor and also
    // look up uniform locations.

    const programInfo = {
        program: shaderProgram,
        attribLocations: {
            vertexPosition: gl.getAttribLocation(shaderProgram, 'aVertexPosition'),
            vertexColor: gl.getAttribLocation(shaderProgram, 'aVertexColor'),
            textureCoord: gl.getAttribLocation(shaderProgram, 'aTextureCoord'),
        },
        uniformLocations: {
            MVPMatrix: gl.getUniformLocation(shaderProgram, 'uMVPMatrix'),
            uSampler: gl.getUniformLocation(shaderProgram, 'uSampler')
            // modelViewMatrix: gl.getUniformLocation(shaderProgram, 'uModelViewMatrix'),
        },
    };

    const programInfo2 = {
        program: shaderProgram2,
        attribLocations: {
            vertexPosition: gl.getAttribLocation(shaderProgram2, 'aVertexPosition'),
            vertexColor: gl.getAttribLocation(shaderProgram2, 'aVertexColor'),
            textureCoord: gl.getAttribLocation(shaderProgram2, 'aTextureCoord'),
        },
        uniformLocations: {
            MVPMatrix: gl.getUniformLocation(shaderProgram2, 'uMVPMatrix'),
            uSampler: gl.getUniformLocation(shaderProgram2, 'uSampler')
            // modelViewMatrix: gl.getUniformLocation(shaderProgram, 'uModelViewMatrix'),
        },
    };

    // Here's where we call the routine that builds all the
    // objects we'll be drawing.
    const buffers = initBuffers(gl);

    var then = 0;

    // Draw the scene repeatedly
    function render(now) {
        now *= 0.001;  // convert to seconds
        const deltaTime = now - then;
        then = now;
        p3 -= 0.05;
        
    Mousetrap.bind('g',function(){
    	gray=(gray+1)%2;});

    Mousetrap.bind('space',function(){ 
        if(player.center[1] <= 3 && f3 == 0 ){
            player.center[1] = 1.5;} 
        if(player.center[1] <= 3 && f3 == 1 ){
            player.center[1] = 3;}     
        });
    Mousetrap.bind('down',function(){ 
        if(player.depth == 0.5){  player.depth = 0.25; }
        else if(player.depth == 0.25){ player.depth = 0.5; }
        });

    
        Mousetrap.bind('left',function(){
            if(player.center[0] >= -1)
            {
                //console.log("dasd");
                player.center[0] -= 2.4;
                police.center[0] -= 2.4;
            }
        }, 'keyup');

          Mousetrap.bind('right',function() {
            if(player.center[0] <= 1)
            {
                player.center[0] += 2.4;
                police.center[0] += 2.4;
            }
        })

          x_min = player.center[0]-0.5;
          x_max = player.center[0]+0.5;
          y_min = player.center[1]-0.5;
          y_max = player.center[1]+0.5;
          z_min = player.center[2]-0.5;
          z_max = player.center[2]+0.5;
          a = player.center[0];
          b = player.center[1];
          c = player.center[2];
         for(let i=0; i<trains.length; i++){
         	x_1 = trains[i].center[0] - 0.5;
         	x_2 = trains[i].center[0] + 0.5;
         	y_1 = trains[i].center[1] - 3;
         	y_2 = trains[i].center[1] + 3;
         	z_1 = trains[i].center[2] - 0.5;
         	z_2 = trains[i].center[2] + 0.5;
         	if(x_1 < a && a < x_2){
         		if(y_1 < b && b < y_2){
         			if(z_1 < c && c < z_2){
         				console.log("collided");
         				//exit();
         			}
         		}
         	}
         }


         for(let i=0; i<coins.length; i++){
         	a = coins[i].center[0];
          	b = coins[i].center[1];
          	c = coins[i].center[2];
          	//console.log(a,b,c,x_min,x_max,y_min,y_max,z_min,z_max);
         	if(x_min < a && a < x_max){
         		if(y_min < b && b < y_max){
         			if(z_min < c && c < z_max){
         				console.log("points");
         				score += 1;
         				vc[i] = 1;
         				//exit();
         			}
         		}
         	}
         }

         for(let i=0; i<board1.length; i++){
         	a = board1[i].position[0];
          	b = board1[i].position[1];
          	c = board1[i].position[2];
         	if(x_min < a && a < x_max){
         		if(y_min < b && b < y_max){
         			if(z_min < c && c < z_max){
         				console.log("crash1");
         				health -= 1;
         				//exit();
         			}
         		}
         	}
         }

         for(let i=0; i<board2.length; i++){
         	a = board2[i].position[0];
          	b = board2[i].position[1] - 0.5;
          	c = board2[i].position[2];
         	if(x_min < a && a < x_max){
         		if(y_min < b && b < y_max){
         			if(z_min < c && c < z_max){
         				console.log("crash2");
         				health -= 1;
         				//exit();
         			}
         		}
         	}
         }

         	a = fly.center[0];
          	b = fly.center[1];
          	c = fly.center[2];
         	if(x_min < a && a < x_max){
         		if(y_min < b && b < y_max){
         			if(z_min < c && c < z_max){
         				console.log("fly");
         				player.center[1] = 2;
         				f1 = 1;
         				//exit();
         			}
         		}
         	}

         	a = spd.center[0];
          	b = spd.center[1];
          	c = spd.center[2];
         	if(x_min < a && a < x_max){
         		if(y_min < b && b < y_max){
         			if(z_min < c && c < z_max){
         				console.log("speed");
         				//player.center[0] = 2;
         				f2 = 1;
         				//exit();
         			}
         		}
         	}

         	a = boot.center[0];
          	b = boot.center[1];
          	c = boot.center[2];
         	if(x_min < a && a < x_max){
         		if(y_min < b && b < y_max){
         			if(z_min < c && c < z_max){
         				console.log("boot");
         				//player.center[0] = 2;
         				f3 = 1;
         				B1 = count;
         				//exit();
         			}
         		}
         	}
        
        count++;
        if( f1 == 1 && count%170 == 0 ){
        	f1 = 0;
        	player.center[1] = 0;
        }
        if( f2 == 1 && count%170 == 0 ){
        	f2 = 0;
        	//player.center[1] = 0;
        }
        if((count - B1) >= 100){
        	f3 = 0;
        }

        if(health <= 0){ //exit(); 
    	}
        drawScene(gl, programInfo, buffers, deltaTime, programInfo2);
        tick();

        requestAnimationFrame(render);
    }
    requestAnimationFrame(render);
}


function tick() {
    if(f2 == 0){
    	cam_pos -= 0.05;
    	player.center[2] -= 0.05;
    }else if(f2 == 1){
    	cam_pos -= 0.1;
    	player.center[2] -= 0.1;
    }
    police.center[2] -= 0.05;
    if(player.center[1] > 0 && f1 == 0){ player.center[1] -= 0.025; }
}

//
// initBuffers
//
// Initialize the buffers we'll need. For this demo, we just
// have one object -- a simple three-dimensional cube.
//
function initBuffers(gl) {

    
    let img = 'rail7.jpg';
    for (let i=0; i<100; i++) {
        rect_track.push(new Rectangle(2,2, new vec3.fromValues(0, -2.5, 4-2*i), img));
        rect_track[rect_track.length - 1].rotate(-90, X_AXIS, ORIGIN);
        rect_track.push(new Rectangle(2,2, new vec3.fromValues(-3, -2.5, 4-2*i), img));
        rect_track[rect_track.length-1].rotate(-90, X_AXIS, ORIGIN);
        rect_track.push(new Rectangle(2,2, new vec3.fromValues(3, -2.5, 4-2*i), img));
        rect_track[rect_track.length-1].rotate(-90, X_AXIS, ORIGIN);
    }

    img = 'wall2.jpg';
    for (let i=0; i<100; i++) {
        brick_wall.push(new Rectangle(2,2, new vec3.fromValues(6,-0.7,4-2*i), img));
        brick_wall[brick_wall.length-1].rotate(-90, Y_AXIS, ORIGIN);
        brick_wall.push(new Rectangle(2,2, new vec3.fromValues(-4,-0.7,4-2*i), img));
        brick_wall[brick_wall.length-1].rotate(-90, Y_AXIS, ORIGIN);
    }
    img = 'grnd.jpg';
    ground = new Ground(300, 10, new vec3.fromValues(0, -2.7, 0), img);

    trains.push(new Trains(new vec3.fromValues(-2.4, 0, -15), 0.5, 3, 0.5));
    trains.push(new Trains(new vec3.fromValues(2.4, 0, -15), 0.5, 3, 0.5));
    // trains.push(new Trains(new vec3.fromValues(-2.4, 0, -45), 0.5, 3, 0.5));
    // trains.push(new Trains(new vec3.fromValues(2.4, 0, -75), 0.5, 3, 0.5));
    player = new cuboidWithTexture(new vec3.fromValues(0, 0, -5), 0.5, 0.5, 0.5);
    police = new Police(new vec3.fromValues(0, 0, 0), 0.5, 0.5, 0.5);
    
    coins.push(new Coins(new vec3.fromValues(0, 0, -10), 0.3, 0.05, 0.3));
    coins.push(new Coins(new vec3.fromValues(0, 0, -30), 0.3, 0.05, 0.3));
    coins.push(new Coins(new vec3.fromValues(-2.4, 0, -25), 0.3, 0.05, 0.3));
    coins.push(new Coins(new vec3.fromValues(2.4, 0, -35), 0.3, 0.05, 0.3));
    coins.push(new Coins(new vec3.fromValues(0, 0, -40), 0.3, 0.05, 0.3));
    coins.push(new Coins(new vec3.fromValues(-2.4, 0, -45), 0.3, 0.05, 0.3));
    coins.push(new Coins(new vec3.fromValues(0, 1, -18), 0.3, 0.05, 0.3));

    // coins.push(new Coins(new vec3.fromValues(0, 0, -50), 0.3, 0.05, 0.3));
    // coins.push(new Coins(new vec3.fromValues(0, 0, -60), 0.3, 0.05, 0.3));
    // coins.push(new Coins(new vec3.fromValues(-2.4, 0, -75), 0.3, 0.05, 0.3));
    // coins.push(new Coins(new vec3.fromValues(2.4, 0, -85), 0.3, 0.05, 0.3));
    // coins.push(new Coins(new vec3.fromValues(0, 0, -70), 0.3, 0.05, 0.3));
    // coins.push(new Coins(new vec3.fromValues(-2.4, 0, -115), 0.3, 0.05, 0.3));
    // coins.push(new Coins(new vec3.fromValues(0, 2, -125), 0.3, 0.05, 0.3));

    //coins.push(new Coins(new vec3.fromValues(0, 2, -20), 0.3, 0.05, 0.3));
    //coins.push(new Coins(new vec3.fromValues(0, 2, -22), 0.3, 0.05, 0.3));
    coins.push(new Coins(new vec3.fromValues(2.4, 2, -43), 0.3, 0.05, 0.3));

    img = 'obs1.jpg';
    board1.push(new Rectangle(1,1, new vec3.fromValues(0, 0, -20), img));

    img = 'obs2.jpg';
    board2.push(new Rectangle(1,1, new vec3.fromValues(-2.5, 0.8, -30), img));

    img = 'signal.jpg'
    signal = new Rectangle(3, 0.5, new vec3.fromValues(-1.5, 0, -100), img);

    fly = new Fly(new vec3.fromValues(2.5, 0, -40), 0.3, 0.3, 0.3);
    spd = new Speed(new vec3.fromValues(0, 0, -25), 0.3, 0.3, 0.3);
    boot = new Boot(new vec3.fromValues(0, 0, -50), 0.3, 0.3, 0.3)

    for(let i=0; i<coins.length; i++){
    	vc[i] = 0;
    }


}

//
// Draw the scene.
//
function drawScene(gl, programInfo, buffers, deltaTime, programInfo2) {
    resize();
    let backgroundColor = COLORS_0_1.SKY_BLUE;
    gl.clearColor(backgroundColor[0], backgroundColor[1], backgroundColor[2], 1.0);  // Clear to black, fully opaque
    gl.clearDepth(1.0);                 // Clear everything
    gl.enable(gl.DEPTH_TEST);           // Enable depth testing
    gl.depthFunc(gl.LEQUAL);            // Near things obscure far things

    // Clear the canvas before we start drawing on it.

    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // Create a perspective matrix, a special matrix that is
    // used to simulate the distortion of perspective in a camera.
    // Our field of view is 45 degrees, with a width/height
    // ratio that matches the display size of the canvas
    // and we only want to see objects between 0.1 units
    // and 100 units away from the camera.

    const fieldOfView = 45 * Math.PI / 180;   // in radians
    const aspect = gl.canvas.clientWidth / gl.canvas.clientHeight;
    const zNear = 0.1;
    const zFar = 50.0;
    const projectionMatrix = mat4.create();

    // note: glmatrix.js always has the first argument
    // as the destination to receive the result.
    mat4.perspective(projectionMatrix,
        fieldOfView,
        aspect,
        zNear,
        zFar);
    gl.useProgram(programInfo.program);

    var GrayBuffer = gl.getUniformLocation(programInfo.program, "uGray");
    gl.uniform1i(GrayBuffer, gray);

    // var FlashBuffer = gl.getUniformLocation(programInfo2.program, "uGray");
    // gl.uniform1i(FlashBuffer, flash);
    // Set the drawing position to the "identity" point, which is
    // the center of the scene.
    const modelViewMatrix = mat4.create();
    const viewMatrix = mat4.create();
    // temp_vector = vec3.create();
    // console.log(temp)

    // Now move the drawing position a bit to where we want to
    // start drawing the square.

    mat4.lookAt(viewMatrix, vec3.fromValues(0, 4, 5+cam_pos), vec3.fromValues(0,0,cam_pos-10), vec3.fromValues(0,1,0));
    // mat4.translate(modelViewMatrix,     // destination matrix
    //     modelViewMatrix,     // matrix to translate
    //     [-0.0, 1.0, -9.0]);  // amount to translate

    const VP = mat4.create();
    mat4.multiply(VP, projectionMatrix, viewMatrix);
    //Write your code to Rotate the cube here//

    
    
    for (let i=0; i<rect_track.length; i++) {
        rect_track[i].draw(programInfo, VP);
    }
    light++;

    for (let i=0; i<brick_wall.length; i++) {
   	if (light%100 < 50) {
    	gl.useProgram(programInfo2.program);
        brick_wall[i].draw(programInfo2, VP);
    }
    else {
    	brick_wall[i].draw(programInfo, VP);	
    }
    }
    gl.useProgram(programInfo.program);
    for (let i=0; i<trains.length; i++) {
        trains[i].draw(programInfo, VP);
    }
    for (let i=0; i<coins.length; i++) {
    	if(vc[i] == 0)
        { coins[i].draw(programInfo, VP); }
    }
    for (let i=0; i<board1.length; i++) {
        board1[i].draw(programInfo, VP);
    }
    for (let i=0; i<board2.length; i++) {
        board2[i].draw(programInfo, VP);
    }

    player.draw(programInfo, VP);
    ground.draw(programInfo, VP);
    signal.draw(programInfo, VP);
    police.draw(programInfo, VP);
    fly.draw(programInfo, VP);
    spd.draw(programInfo, VP);
    boot.draw(programInfo, VP);
    //console.log(player.center);

    document.getElementById("score").innerHTML = score;
    document.getElementById("health").innerHTML = health;

    // Update the rotation for the next draw
    cubeRotation += deltaTime;
}

//
// Initialize a shader program, so WebGL knows how to draw our data
//
function initShaderProgram(gl, vsSource, fsSource) {
    const vertexShader = loadShader(gl, gl.VERTEX_SHADER, vsSource);
    const fragmentShader = loadShader(gl, gl.FRAGMENT_SHADER, fsSource);

    // Create the shader program

    const shaderProgram = gl.createProgram();
    gl.attachShader(shaderProgram, vertexShader);
    gl.attachShader(shaderProgram, fragmentShader);
    gl.linkProgram(shaderProgram);

    // If creating the shader program failed, alert

    if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
        alert('Unable to initialize the shader program: ' + gl.getProgramInfoLog(shaderProgram));
        return null;
    }

    return shaderProgram;
}

//
// creates a shader of the given type, uploads the source and
// compiles it.
//
function loadShader(gl, type, source) {
    const shader = gl.createShader(type);

    // Send the source to the shader object

    gl.shaderSource(shader, source);

    // Compile the shader program

    gl.compileShader(shader);

    // See if it compiled successfully

    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        alert('An error occurred compiling the shaders: ' + gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
        return null;
    }

    return shader;
}
