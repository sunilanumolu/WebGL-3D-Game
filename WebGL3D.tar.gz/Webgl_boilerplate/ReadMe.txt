This is an OpenGl game

left: <-
right: ->
compress: down arrow
space: jump
coins
police
jetpack
speeder
boots
